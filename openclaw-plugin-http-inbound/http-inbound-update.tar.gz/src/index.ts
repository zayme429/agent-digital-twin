import { httpInboundPlugin } from "./channel.js";

const plugin = {
  id: "http-inbound",
  name: "HTTP Inbound API",
  description: "HTTP Inbound channel for OpenClaw - allows custom apps to connect via REST API",
  register(api: any) {
    console.log("[http-inbound] register() called with api:", api);
    api.registerChannel({ plugin: httpInboundPlugin });
    console.log("[http-inbound] registerChannel() completed");
  }
};

export default plugin;


